Watch the priority of some processes.

In case if you don't want some of your processes stay with "Normal" priority you'd need a special tool, and here is one.

Powershell + Task Scheduler are used.

Since it deals with process priority, it is a somewhat dangerous tool. Read "usage.txt" first, then review the actual scripts, and only then run it.

