#requires -version 4.0
# we definitely need administrator privileges: otherwise not only the installation fails, but when uninstalling, 'Get-ScheduledTask' hushes up / conceals the task we need
#requires -runasadministrator

param ([Parameter(Mandatory)] [ValidateSet('install', 'uninstall')] [string]$script_action)
$ConfirmPreference = 'None'

#$task_name = "test1"
$task_name = "Watch process priority"
# unused :/
$user = "Administrator"
$target_file_name = "watch_process_creation.bat"


function Task_Add
{
#	$time = New-ScheduledTaskTrigger -At 12:00 -Once
# nope, this doesn't start the task immediately
#	$time = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(7)
#	$time = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(3)
	$time = New-ScheduledTaskTrigger -AtStartup
	$target_file_name = $PSScriptRoot + '\' + $target_file_name
#	$action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "_nonexisting.ps1"
	$action = New-ScheduledTaskAction -Execute "$target_file_name"
#	$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "$target_file_name"
# it looks like we need to run it as SYSTEM if we want "Run whether user is logged on or not" but don't want to enter user name / password
# yep, it works for "SYSTEM", but for "Administrator" is being reset to "Run only when user is logged on"
# it works without "-LogonType ServiceAccount" too
#	$principal = New-ScheduledTaskPrincipal -UserID "NT AUTHORITY\SYSTEM" -LogonType ServiceAccount -RunLevel Highest
	$principal = New-ScheduledTaskPrincipal -UserID "NT AUTHORITY\SYSTEM"
#	$principal = New-ScheduledTaskPrincipal -UserID $user -LogonType ServiceAccount -RunLevel Highest
#	$principal = New-ScheduledTaskPrincipal -UserID $user
#	Register-ScheduledTask -TaskName $task_name -Trigger $time -User $user -Action $action
	Register-ScheduledTask -TaskName $task_name -Trigger $time -Action $action -Principal $principal
	'task added'
}

function Task_Remove
{
#	'removing task'
	Unregister-ScheduledTask -TaskName $task_name -Confirm:0
	'task removed'
}

# no need
#function Task_Get
#{
#}

# good, creating task with the same name fails (means we will get here only one task of this name (and thus will have to remove only one))
$tasks = Get-ScheduledTask -TaskName $task_name -ErrorAction SilentlyContinue
#"tasks count is: " + $tasks.count
$num = ($tasks | Measure-Object).count
#"tasks num is: " + $num
if ($num)
{
	Task_Remove
}
else
#if (-not $num)
{
	if ($script_action -eq 'uninstall')
	{
# this also happens when having not enough privileges ('Get-ScheduledTask' silently ignores tasks for a users with higher privileges)
		"task not found"
		Exit 1
	}
}

if ($script_action -eq 'install')
{
	Task_Add
}

