#requires -version 4.0
# the "realtime priority" part requires that; otherwise the priority change will not fail, but the priority will be set to "high"
# though no access when trying to change priorities for a processes of other users; thus administrator access is mandatory for the most of cases (either "realtime" priority is necessary, or the target process runs for another user)
# I am releasing this script with this requirement being active, but you may disable it for test (read first the strings above)
#requires -runasadministrator


$priority_level_id___low = 64
$priority_level_id___below_normal = 16384
$priority_level_id___normal = 32
$priority_level_id___above_normal = 32768
$priority_level_id___high = 128
$priority_level_id___realtime = 256


# could also try disable 'SeIncreaseBasePriorityPrivilege' for such a process

function MaybeSetPriorityRealtime
{
# *name '$pid' is in use
param ([Parameter(Mandatory)] [int]$pid_)

#	'MaybeSetPriorityRealtime'
#	$pid_

	$priority_level_id = $priority_level_id___low
	$priority_level_id = $priority_level_id___below_normal
	$priority_level_id = $priority_level_id___normal
	$priority_level_id = $priority_level_id___above_normal
	$priority_level_id = $priority_level_id___high
	$priority_level_id = $priority_level_id___realtime

# lets see if that is the only process with that name
	$proc_name = Get-Process -Id $pid_ | Select -Expand ProcessName
	$processes = Get-Process -ProcessName $proc_name
#	$processes.Count
# not allow to set realtime priority to a multiple number of processes having the same name
	if ($processes.Count -ne 1)
	{
		Write-Host 'MaybeSetPriorityRealtime: not allowing to change the priority when the number of processes with this name is more than 1'
		return
	}

	'MaybeSetPriorityRealtime (' + $pid_ + ', ' + '"' + $processes[0].ProcessName + '"' + ') processing'

	$filter = "ProcessId=$pid_"
#	'the filter is: ' + $filter
	$cim_processes = Get-CimInstance Win32_Process -Filter $filter
	$num = ($cim_processes | Measure-Object).count
#	'the number of processes is: ' + $num
# assertion
	if ($num -ne 1)
	{
		throw
	}
	$cim_process = $cim_processes[0]
#	$cim_process = $cim_processes
# *Winamp requires a delay, because it changes its priority on its own (so if it has realtime priority and changes it to realtime, it gets high priority instead)
	Start-Sleep -Seconds 1
#	Start-Sleep -Seconds 5
#	"sleep period has passed; changing the priority now"
#	Write-Output 'changing the priority'
# *both these do output 2 lines of some trash table
# lets use 'Out-Null' to avoid that
	$cim_process | Invoke-CimMethod -Name SetPriority -Arguments @{Priority=$priority_level_id} | Out-Null
#	Write-Host 'writehost: priority changed'
}

function WatchProcessPriority
{
param ([Parameter(Mandatory)] [int]$pid_)

# unused
	$priority_level_id = $priority_level_id___low
	$priority_level_id = $priority_level_id___below_normal
	$priority_level_id = $priority_level_id___normal
	$priority_level_id = $priority_level_id___above_normal
#	$priority_level_id = $priority_level_id___high
#	$priority_level_id = $priority_level_id___realtime

	"WatchProcessPriority " + $pid_
#	"WPP " + $pid_

# 'Win32_Process' (and underlaying base classes) has no methods which could give live information about process status
# I don't see how to get a live and real handle to a process; thus lets just get the process by id each time anew :/
if (0)
{
	$process=[System.Diagnostics.Process]::GetProcessById($pid_)
	"process:"
	$process
	$threads=$process.Threads
	"threads count:"
	$threads.count
	"threads:"
	$threads
	$threads | select Id,ThreadState,WaitReason
	Start-Sleep -Seconds 5
# this value is still the same after process exit :(
	"threads count:"
	$threads.count
	return
}

if (0)
{
	$filter = "ProcessId=$pid_"
#	'the filter is: ' + $filter
	$cim_processes = Get-CimInstance Win32_Process -Filter $filter
	$num = ($cim_processes | Measure-Object).count
#	'the number of processes is: ' + $num
# assertion
	if ($num -ne 1)
	{
		throw
	}
	$cim_process = $cim_processes[0]
#	Write-Host ($cim_process | Format-Table | Out-String)
#	Write-Host "space"
#	$cim_process | Get-Member
#	Write-Host ($cim_process | Get-Member)
#	Write-Host ($cim_process.ThreadCount)
#	Write-Host "space 2"
#	Start-Sleep -Seconds 5
# not being updated :(
#	Write-Host ($cim_process.ThreadCount)
#	Write-Host "space 3"
	return
	while (1)
	{
		Start-Sleep -Seconds 1
#		Start-Sleep -Seconds 5
# first lets see if the project is still active
#		$result = ($cim_process | Invoke-CimMethod -Name ThreadCount)
#		$result
#		Write-Output 'changing the priority'
#		$cim_process | Invoke-CimMethod -Name SetPriority -Arguments @{Priority=$priority_level_id}
#		Write-Host 'changed the priority'
	}
}

# a poo-code version: get the process by id each time anew :/
if (0)
{
	while (1)
	{
		$filter = "ProcessId=$pid_"
#		'the filter is: ' + $filter
		$cim_processes = Get-CimInstance Win32_Process -Filter $filter
		$num = ($cim_processes | Measure-Object).count
#		'the number of processes is: ' + $num
# assertion
		if ($num -ne 1)
		{
			throw
		}
		$cim_process = $cim_processes[0]
		Start-Sleep -Seconds 1
#		Start-Sleep -Seconds 5
# first lets see if the project is still active
#		$result = ($cim_process | Invoke-CimMethod -Name ThreadCount)
#		$result
#		Write-Output 'changing the priority'
#		$cim_process | Invoke-CimMethod -Name SetPriority -Arguments @{Priority=$priority_level_id}
		Write-Host 'changed the priority'
	}
}

# one more try: 'Get-Process' returns an object of a different kind
# yep, this one is live: at least 'HasExited' works
# yep, works simply that; why a helping threads then recommended to me other, way less useful stuff?
if (1)
{
	$processes = Get-Process -Id $pid_
	$num = $processes.count
#	$num = ($processes | Measure-Object).count
#	$num
#	'the number of processes is: ' + $num
# assertion
	if ($num -ne 1)
	{
#		throw
		return
	}
#	"process members"
	$process = $processes[0]
# Handles = Handlecount Name = ProcessName NPM = NonpagedSystemMemorySize64 PM = PagedMemorySize64 VM = VirtualMemorySize64 WS = WorkingSet64 System.EventHandler Disposed(System.Object, System.EventArgs) System.Diagnostics.DataReceivedEventHandler ErrorDataReceived(System.Object, System.Diagnostics.DataReceivedEventArgs) System.EventHandler Exited(System.Object, System.EventArgs) System.Diagnostics.DataReceivedEventHandler OutputDataReceived(System.Object, System.Diagnostics.DataReceivedEventArgs) void BeginErrorReadLine() void BeginOutputReadLine() void CancelErrorRead() void CancelOutputRead() void Close() bool CloseMainWindow() System.Runtime.Remoting.ObjRef CreateObjRef(type requestedType) void Dispose(), void IDisposable.Dispose() bool Equals(System.Object obj) int GetHashCode() System.Object GetLifetimeService() type GetType() System.Object InitializeLifetimeService() void Kill() void Refresh() bool Start() string ToString() bool WaitForExit(int milliseconds), void WaitForExit() bool WaitForInputIdle(int milliseconds), bool WaitForInputIdle() string __NounName=Process int BasePriority {get;} System.ComponentModel.IContainer Container {get;} bool EnableRaisingEvents {get;set;} int ExitCode {get;} datetime ExitTime {get;} System.IntPtr Handle {get;} int HandleCount {get;} bool HasExited {get;} int Id {get;} string MachineName {get;} System.Diagnostics.ProcessModule MainModule {get;} System.IntPtr MainWindowHandle {get;} string MainWindowTitle {get;} System.IntPtr MaxWorkingSet {get;set;} System.IntPtr MinWorkingSet {get;set;} System.Diagnostics.ProcessModuleCollection Modules {get;} int NonpagedSystemMemorySize {get;} long NonpagedSystemMemorySize64 {get;} int PagedMemorySize {get;} long PagedMemorySize64 {get;} int PagedSystemMemorySize {get;} long PagedSystemMemorySize64 {get;} int PeakPagedMemorySize {get;} long PeakPagedMemorySize64 {get;} int PeakVirtualMemorySize {get;} long PeakVirtualMemorySize64 {get;} int PeakWorkingSet {get;} long PeakWorkingSet64 {get;} bool PriorityBoostEnabled {get;set;} System.Diagnostics.ProcessPriorityClass PriorityClass {get;set;} int PrivateMemorySize {get;} long PrivateMemorySize64 {get;} timespan PrivilegedProcessorTime {get;} string ProcessName {get;} System.IntPtr ProcessorAffinity {get;set;} bool Responding {get;} Microsoft.Win32.SafeHandles.SafeProcessHandle SafeHandle {get;} int SessionId {get;} System.ComponentModel.ISite Site {get;set;} System.IO.StreamReader StandardError {get;} System.IO.StreamWriter StandardInput {get;} System.IO.StreamReader StandardOutput {get;} System.Diagnostics.ProcessStartInfo StartInfo {get;set;} datetime StartTime {get;} System.ComponentModel.ISynchronizeInvoke SynchronizingObject {get;set;} System.Diagnostics.ProcessThreadCollection Threads {get;} timespan TotalProcessorTime {get;} timespan UserProcessorTime {get;} int VirtualMemorySize {get;} long VirtualMemorySize64 {get;} int WorkingSet {get;} long WorkingSet64 {get;} PSConfiguration {Name, Id, PriorityClass, FileVersion} PSResources {Name, Id, Handlecount, WorkingSet, NonPagedMemorySize, PagedMemorySize, PrivateMemorySize, VirtualMemorySize, Threads.Count, TotalProcessorTime} System.Object Company {get=$this.Mainmodule.FileVersionInfo.CompanyName;} System.Object CPU {get=$this.TotalProcessorTime.TotalSeconds;} System.Object Description {get=$this.Mainmodule.FileVersionInfo.FileDescription;} System.Object FileVersion {get=$this.Mainmodule.FileVersionInfo.FileVersion;} System.Object Path {get=$this.Mainmodule.FileName;} System.Object Product {get=$this.Mainmodule.FileVersionInfo.ProductName;} System.Object ProductVersion {get=$this.Mainmodule.FileVersionInfo.ProductVersion;}
#	$process | Get-Member
#	Write-Host ($process | Get-Member)
#	Start-Sleep -Seconds 5
#	Write-Host ("has exited: " + $process.HasExited)
#	return
	while (1)
	{
# it is a property, but it give a live data
		if ($process.HasExited)
		{
			break
		}
#		Start-Sleep -Seconds 1
# 'HasExited' works on its own, but other values need a refresh
# 'Refresh()' and 'PriorityClass' do not report any error if the process has exited
# 'PriorityClass' getter gives something empty if the process has exited
		$process.Refresh()
# priority
# "Idle", "BelowNormal", "Normal", "AboveNormal", "High", "RealTime"
#		Write-Host $process.PriorityClass
#		$process.PriorityClass = "Idle"
# a certain condition which is of interest for us
		if ($process.PriorityClass -eq "Normal")
		{
#			$process.PriorityClass = "Idle"
#			$process.PriorityClass = "BelowNormal"
#			$process.PriorityClass = "Normal"
			$process.PriorityClass = "AboveNormal"
		}
		Start-Sleep -Seconds 1
		Write-Host 'ping'
	}
}

	Write-Host 'exiting the priority watching loop'
}

Write-Verbose -Verbose "Monitoring for new processes; press Ctrl-C to exit..."
try
{
	$query = '
	SELECT TargetInstance FROM __InstanceCreationEvent 
	WITHIN 1 WHERE 
	TargetInstance ISA "Win32_Process"
	'

	Register-CimIndicationEvent -ErrorAction Stop -Query $query -SourceIdentifier ProcessStarted

#	while ($true)
	while (1)
	{
		($e = Wait-Event -SourceIdentifier ProcessStarted) | Remove-Event
#		Write-Host ($e.SourceEventArgs.NewEvent | Format-Table | Out-String)
#		Write-Host ($e.SourceEventArgs.NewEvent.TargetInstance | Format-Table | Out-String)
#		Write-Host ($e.SourceEventArgs.NewEvent.TargetInstance | Format-List -Force | Out-String)
#		$e.SourceEventArgs.NewEvent.TargetInstance | Get-Member
# it gets that only 'Handle', 'CimClass', 'CimInstanceProperties' and 'CimSystemProperties' are present
#		$e.SourceEventArgs.NewEvent.TargetInstance | Select-Object -Property *
		# Get the PID (process ID) from the event
		$proc_id = $e.SourceEventArgs.NewEvent.TargetInstance.Handle
#		$proc_id
#		$proc_id = $e.SourceEventArgs.NewEvent.TargetInstance.ProcessId
#		$proc_id
# declare the variable (one of a lesser described actions of Powershell)
# ow, that isn't declaring, but sending to the output
#		[string]$proc_name
		$proc_name = ""
#		$proc_name = $e.SourceEventArgs.NewEvent.TargetInstance.ProcessName
#		$proc_name
		try
		{
# test: a nonexisting process
#			$proc_name = Get-Process -Id 9999 | Select -Expand ProcessName
#			$proc_name = Get-Process -Id 9999 -ErrorAction stop | Select -Expand ProcessName
			# Sample processing: print the properties of the process.
# 'Get-Process' gives process name without giving ".exe" extension
#			Get-Process -Id $proc_id | Format-List
#			$proc_name = Get-Process -Id $proc_id | Select ProcessName
#			$proc_name = Get-Process -Id $proc_id | Select -Expand ProcessName
# need '-ErrorAction stop', otherwise 'try'/'catch' doesn't catch
# *'Select' reports errors too; so have to direct its errors too
			$proc_name = Get-Process -Id $proc_id -ErrorAction stop | Select -Expand ProcessName -ErrorAction stop
		}
		catch
		{
# the process didn't live for long, so skip this event
			continue
		}
#		"successfully got a process name"
#		$proc_name
# don't omit 'if()' before braces, otherwise the function call will not get the argument
#		if ($proc_name -eq 'Winamp')
#		if ($proc_name -eq 'Notepad2')
		if ($proc_name -eq 'Audacious')
		{
#			'Audacious'
#			MaybeSetPriorityRealtime $proc_id
			MaybeSetPriorityRealtime -pid $proc_id
# test
#			WatchProcessPriority -pid $proc_id
#			$job = Start-Job { WatchProcessPriority -pid $proc_id }
## this likely doesn't work in Powershell 5
#			$job = Start-Job -ScriptBlock ${Function:WatchProcessPriority} { WatchProcessPriority -pid $proc_id }
#			$job = Start-Job -ScriptBlock ${Function:WatchProcessPriority} -ArgumentList $proc_id { WatchProcessPriority -pid $proc_id }
#			$job = Start-Job -ScriptBlock ${Function:WatchProcessPriority} -ArgumentList $proc_id
#			Start-Sleep -Seconds 5
#			Receive-Job $job
#			Start-Sleep -Seconds 5
#			Receive-Job $job
		}
		if ($proc_name -eq 'Winamp')
		{
#			'Winamp'
			MaybeSetPriorityRealtime -pid $proc_id
		}
		if ($proc_name -eq 'vlc')
		{
#			'VLC'
			MaybeSetPriorityRealtime -pid $proc_id
		}
#		if ($proc_name -eq 'GZDoom 4.10.0')
		if ($proc_name -eq 'GZDoom')
		{
#			MaybeSetPriorityRealtime -pid $proc_id
#			"it is GZDoom"
			Write-Host "running a watching thread for GZDoom"
#			WatchProcessPriority -pid $proc_id
			$job = Start-Job -ScriptBlock ${Function:WatchProcessPriority} -ArgumentList $proc_id
		}
	}
}
finally
{
  UnRegister-Event ProcessStarted
}

